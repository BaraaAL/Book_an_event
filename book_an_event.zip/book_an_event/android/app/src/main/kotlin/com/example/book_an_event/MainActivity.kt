package com.example.book_an_event

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
